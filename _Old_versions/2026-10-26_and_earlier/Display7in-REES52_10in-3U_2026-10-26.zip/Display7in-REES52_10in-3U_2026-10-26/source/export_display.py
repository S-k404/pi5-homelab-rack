import os
import cadquery as cq
import display as dp
import export_render as er

OUT = "out_display"
for sub in ("STL_for_printing", "STEP_for_Onshape", "images"):
    os.makedirs(f"{OUT}/{sub}", exist_ok=True)
B = dp.body()
bb = B.val().BoundingBox()
cq.exporters.export(B.translate((-bb.xmin, -bb.ymin, -bb.zmin)), f"{OUT}/STL_for_printing/Display7_3U_Body.stl", tolerance=0.05, angularTolerance=0.1)
c = dp.clip(); cb = c.val().BoundingBox()
cq.exporters.export(c.translate((-cb.xmin, -cb.ymin, -cb.zmin)), f"{OUT}/STL_for_printing/Display7_Clip_x4.stl", tolerance=0.05, angularTolerance=0.1)
cq.exporters.export(B, f"{OUT}/STEP_for_Onshape/Display7_3U_Body.step")
cq.exporters.export(c, f"{OUT}/STEP_for_Onshape/Display7_Clip_x4.step")
asm = cq.Assembly().add(B, name="body", color=cq.Color("gray")).add(dp.glass_dummy(), name="screen", color=cq.Color("black"))
for i, cl in enumerate(dp.clips()):
    asm.add(cl, name=f"clip{i}", color=cq.Color("gray"))
for s in (1, -1):
    asm.add(dp.ear(s), name=f"ear{s}", color=cq.Color("gray"))
asm.export(f"{OUT}/STEP_for_Onshape/Display7_3U_ASSEMBLY.step")
er.OUT = OUT
lims = ((-140, 140), (-90, 20), (-80, 80))
er.render([(B, "#8d9298"), (dp.glass_dummy(), "#15171c"), (dp.ear(1), "#55585e"), (dp.ear(-1), "#55585e")],
          "display_front.png", 12, 64, "7-inch display module (3U): bezel, ears", lims)
er.render([(B, "#8d9298"), (dp.glass_dummy(), "#15171c"), (dp.driver_dummy(), "#2f8f5b")] + [(x, "#55585e") for x in dp.clips()],
          "display_back.png", 28, -118, "From behind: screen pocket, 4 clips, driver-board tray", lims)
print("done")
