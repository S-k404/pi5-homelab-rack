# NIIMBOT B1 Face-Out Dock — 10-inch 3U Rack Unit (v3, light)

The B1 stands on its long side with its **top facing out of the rack**. The label slot, power button, status light and lid all face you, so you can use the printer without taking it out:

- **Print in place:** labels feed straight out the front.
- **Power button and light:** right in front of you.
- **Change rolls:** the lid opens outward. There's no frame over the top or sides of the printer's face.
- **Open-slide button:** there's 24 mm of finger room on each side, above guides that are only 18 mm tall.
- **Take it out while racked:** tip the printer forward to upright, lift it 3.5 mm over the lip, then slide it out the front. It has 20 mm of room under the unit above. A thumb scoop in the bottom bar helps.

The printer leans back 8° against a back rest, and a 2.5 mm lip holds its bottom edge, so pressing the button or tearing a label won't tip it forward.

![Front](images/dock_front.png)
![Section](images/dock_side.png)
![Empty](images/dock_empty.png)

**Size:** 254 × 132.55 mm panel (3U), 95 mm deep. It goes in the middle 3U of the printed 8U mini rack (Pi unit below, 7-inch screen above).

## New in v3: about 170 g instead of 240 g
- The cradle is now three 4 mm ribs plus the side guides, run down to the floor, instead of a solid wedge.
- Thinner walls: the side walls and floor are 2.4 mm, and the back rest and ears are 3 mm.
- Bigger side windows (104 × 62 mm) and windows in the floor and back rest.
- The ear posts are hollow between the inserts, and the bottom bar is a 4 mm wall.
- Print with 3 walls and 15% infill. All 19 checks still pass.

## New in v2.1 (ideas from other designs)
- **Lite windows in both side walls,** 84 × 50 mm each, from the NIIMBOT B1 Pro wall organizer. They save filament and let air through. The rounded ends print without bridging.
- **Rear USB-C route,** also from the wall organizer: run the cable through the notch in the back rest or past a side guide, then out the open back to a Pi USB port. That keeps the printer charged, and the Pi can print to it with `niimprint`.
- **Felt pad,** from the B1 rugged cases: stick felt on the cradle floor and back rest so the printer doesn't rattle.
- **Label strip:** the bottom bar is 190 × 19 mm, enough for a B1 label such as "B1 · 50×30" for the loaded roll.
- **Tool-less removal,** from DeskPi's front-loading plates: fit M5 thumbscrews instead of the M5 × 12 screws, and the dock comes out by hand.

Spare rolls don't fit inside a 3U dock. Storing them would take a 4U unit, or keep them elsewhere.

## Print list
PETG, 0.2 mm layers, 3 walls, 15% infill, **no supports**. About 145 g for the body and 13 g per ear.

| File (`STL_for_printing/`) | Qty | Size (mm) | Orientation |
|---|---|---|---|
| `B1_Dock_3U_Body.stl` | 1 | 214 × 95 footprint, 130 tall | floor down (already laid out) |
| `B1_Dock_3U_Ear_x2.stl` | **2** | 28 × 132.55 × 3 | flat. Both ears are the same part; turn one 180°. |

## Hardware
| Item | Qty |
|---|---|
| M3 heat-set inserts (Ø4 hole, 6 deep), in the front posts | 4 |
| M3 × 8 countersunk, ears to body | 4 |
| M5 × 12 button-head screws (or M5 thumbscrews for tool-less removal), plus washers | 4 |
| Self-adhesive felt sheet (optional) | 1 |

## Assembly
1. Melt in the 4 inserts in the rebated strips either side of the window.
2. Screw on the ears.
3. Rack the dock.
4. Set the B1 in with its top facing out and its bottom edge behind the lip, then let it lean back. Put the label slot at whichever end you like; the dock is symmetric.
5. Route the USB-C cable out the back.

## Check by hand
- **Lid hinge:** check that the lid clears the 2.5 mm lip when it swings open. If it doesn't, file the lip down. The 8° lean alone keeps the printer seated.
- **Open-slide side:** if the open-slide button ends up facing down, stand the B1 on its other long side.

`VERIFICATION_dock.txt`: 19 checks, 0 fail. The scripts in `source/` regenerate every file.
