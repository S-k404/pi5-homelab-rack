"""Filament estimate from each STL's volume and surface area: walls/skins printed solid, the rest at the infill %."""
import sys
import trimesh
RHO = 1.27  # PETG g/cm3


def grams(path, walls, infill, line=0.045, skin=0.10):
    m = trimesh.load(path)
    V, A = m.volume / 1000, m.area / 100              # cm3, cm2
    shell = min(V, A * (0.6 * walls * line + 0.4 * skin))
    return (shell + (V - shell) * infill) * RHO


PARTS = [  # file, qty, walls, infill
    ("out_rack/STL_for_printing/Rack_SideFrame_2U_x2.stl", 2, 3, 0.20),
    ("out_rack/STL_for_printing/Rack_SideFrame_3U_x2.stl", 2, 3, 0.20),
    ("out_rack/STL_for_printing/Rack_BaseBar_x2.stl", 2, 3, 0.15),
    ("out_rack/STL_for_printing/Rack_Splice_x8.stl", 8, 3, 0.30),
    ("out_rack/STL_for_printing/Rack_TopHalf_x2.stl", 2, 3, 0.15),
    ("out_rack/STL_for_printing/Rack_Handle_x1.stl", 1, 3, 0.25),
    ("out_dock/STL_for_printing/B1_Dock_3U_Body.stl", 1, 3, 0.15),
    ("out_dock/STL_for_printing/B1_Dock_3U_Ear_x2.stl", 2, 3, 0.15),
]
if __name__ == "__main__":
    tot = {"rack": 0, "dock": 0}
    for f, q, w, inf in PARTS:
        g = grams(f, w, inf)
        tot["rack" if "Rack" in f else "dock"] += g * q
        print(f"{f.split('/')[-1]:32s} x{q}  {g:5.0f} g each  {g*q:5.0f} g  ({w} walls, {inf:.0%})")
    print({k: round(v) for k, v in tot.items()}, "total", round(sum(tot.values())), "g")
