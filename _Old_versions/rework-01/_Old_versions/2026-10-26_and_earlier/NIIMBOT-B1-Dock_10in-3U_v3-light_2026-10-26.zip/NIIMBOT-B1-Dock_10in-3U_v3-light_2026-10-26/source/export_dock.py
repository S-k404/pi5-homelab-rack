import os
import numpy as np
import cadquery as cq
import trimesh
import b1_dock as d
from export_render import mesh, render   # reuses the renderer (also re-exports the 2U drawer files)

OUT = "out_dock"
for sub in ("STL_for_printing", "STEP_for_Onshape", "images"):
    os.makedirs(f"{OUT}/{sub}", exist_ok=True)

B, EL, ER, P = d.body(), d.ear(-1), d.ear(1), d.b1_dummy()

def to_bed(shape, rot):
    s = shape
    for axis, ang in rot:
        s = s.rotate((0, 0, 0), axis, ang)
    bb = s.val().BoundingBox()
    return s.translate((-bb.xmin, -bb.ymin, -bb.zmin))

# body: floor down -> model y becomes print Z
cq.exporters.export(to_bed(B, [((1, 0, 0), 90)]), f"{OUT}/STL_for_printing/B1_Dock_3U_Body.stl", tolerance=0.05, angularTolerance=0.1)
cq.exporters.export(to_bed(ER, []), f"{OUT}/STL_for_printing/B1_Dock_3U_Ear_x2.stl", tolerance=0.05, angularTolerance=0.1)
cq.exporters.export(B, f"{OUT}/STEP_for_Onshape/B1_Dock_3U_Body.step")
cq.exporters.export(ER, f"{OUT}/STEP_for_Onshape/B1_Dock_3U_Ear_x2.step")
asm = cq.Assembly()
for n, s, c in (("body", B, "gray"), ("ear_a", EL, "gray"), ("ear_b", ER, "gray"), ("niimbot_b1_dummy", P, "lightblue")):
    asm.add(s, name=n, color=cq.Color(c))
asm.export(f"{OUT}/STEP_for_Onshape/B1_Dock_3U_ASSEMBLY.step")

import export_render as er
er.OUT = OUT
grey, dark, blue = "#a3a8ad", "#6b7075", "#4f9fe0"
lims = ((-140, 140), (-130, 60), (-75, 75))
er.render([(B, grey), (EL, dark), (ER, dark), (P, blue)], "dock_front.png", 14, 70,
          "3U face-out dock: B1's top (labels, button, light, lid) faces you", lims)
er.render([(B, grey), (EL, dark), (ER, dark), (P, blue)], "dock_side.png", 6, 8,
          "Side view: leaned back 8°, 2.5 mm front lip, open top", lims)
er.render([(B, grey), (EL, dark), (ER, dark)], "dock_empty.png", 38, 62,
          "Empty: cradle, low side guides, finger room, cable notch", lims)

# overhang report for the print orientation
m = trimesh.load(f"{OUT}/STL_for_printing/B1_Dock_3U_Body.stl")
n, c, z0 = m.face_normals, m.triangles_center, m.bounds[0][2]
down = (n[:, 2] < -0.71) & (c[:, 2] > z0 + 0.05)
print("watertight", m.is_watertight, "extents", np.round(m.extents, 1), "overhang>45deg mm2", round(m.area_faces[down].sum()))
print("done")
