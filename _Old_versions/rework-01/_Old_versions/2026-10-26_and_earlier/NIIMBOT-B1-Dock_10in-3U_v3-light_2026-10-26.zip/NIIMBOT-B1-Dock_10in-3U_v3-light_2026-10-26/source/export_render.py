import os
import numpy as np
import cadquery as cq
import trimesh
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import b1_drawer as d

OUT = "out"
os.makedirs(f"{OUT}/STL_for_printing", exist_ok=True)
os.makedirs(f"{OUT}/STEP_for_Onshape", exist_ok=True)
os.makedirs(f"{OUT}/images", exist_ok=True)

C, T, F, EL, ER, B = d.carcass(), d.tray(), d.fascia(), d.ear(-1), d.ear(1), d.b1_dummy()

# print parts, each laid in its print orientation
def to_print(shape, rot):
    s = shape
    for axis, ang in rot:
        s = s.rotate((0, 0, 0), axis, ang)
    bb = s.val().BoundingBox()
    return s.translate((-bb.xmin, -bb.ymin, -bb.zmin))

prints = {
    "B1_Drawer_Carcass": (C, [((1, 0, 0), 180)]),              # open back face down, collar on top
    "B1_Drawer_Tray": (T, [((1, 0, 0), 90)]),                  # floor down
    "B1_Drawer_Fascia": (F, []),                               # front face down
    "B1_Drawer_Ear_x2": (ER, []),
}
# fix: decide orientation by checking which face lands on bed
for name, (shape, rot) in prints.items():
    p = to_print(shape, rot)
    cq.exporters.export(p, f"{OUT}/STL_for_printing/{name}.stl", tolerance=0.05, angularTolerance=0.1)
    cq.exporters.export(shape, f"{OUT}/STEP_for_Onshape/{name}.step")

asm = cq.Assembly()
for name, shp, col in (("carcass", C, "gray"), ("tray", T, "orange"), ("fascia", F, "orange"),
                       ("ear_left", EL, "gray"), ("ear_right", ER, "gray"), ("niimbot_b1_dummy", B, "lightblue")):
    asm.add(shp, name=name, color=cq.Color(col))
asm.save(f"{OUT}/STEP_for_Onshape/B1_Drawer_ASSEMBLY_closed.step")


def mesh(shape):
    vs, ts = shape.val().tessellate(0.3, 0.3)
    v, t = np.array([(p.x, p.y, p.z) for p in vs]), np.array(ts)
    v, t = trimesh.remesh.subdivide_to_size(v, t, max_edge=6.0)   # small faces -> clean depth sorting
    return v, t


def render(parts, fname, elev, azim, title, lims=((-140, 140), (-190, 190), (-140, 140))):
    fig = plt.figure(figsize=(11, 7), dpi=140)
    ax = fig.add_subplot(111, projection="3d")
    tris, cols = [], []
    light = np.array([0.35, 0.6, 0.72]); light /= np.linalg.norm(light)
    for shp, color in parts:
        v, t = mesh(shp)
        P = v[:, [0, 2, 1]].copy()
        P[:, 1] = -P[:, 1]           # front of the rack faces +y (towards the camera)
        tri = P[t]
        n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        n /= (np.linalg.norm(n, axis=1, keepdims=True) + 1e-9)
        shade = 0.42 + 0.58 * np.clip(np.abs(n @ light), 0, 1)
        base = np.array(matplotlib.colors.to_rgb(color))
        tris.append(tri); cols.append(np.clip(base[None, :] * shade[:, None], 0, 1))
    pc = Poly3DCollection(np.concatenate(tris), facecolors=np.concatenate(cols), edgecolors="none")
    ax.add_collection3d(pc)          # one collection -> per-triangle depth sorting
    ax.set_xlim(*lims[0]); ax.set_ylim(*lims[1]); ax.set_zlim(*lims[2])
    ax.set_box_aspect([b - a for a, b in lims])
    ax.view_init(elev=elev, azim=azim)
    ax.set_axis_off()
    ax.set_title(title, fontsize=13)
    plt.tight_layout()
    plt.savefig(f"{OUT}/images/{fname}", bbox_inches="tight")
    plt.close(fig)


grey, dark, orange, blue = "#a3a8ad", "#6b7075", "#e8833a", "#4f9fe0"
dz = -d.TRAVEL
render([(C, grey), (EL, dark), (ER, dark), (T, orange), (F, orange), (B, blue)],
       "drawer_closed.png", 16, 62, "Closed: 10-inch 2U, ears match the Pi unit",
       ((-140, 140), (-200, 60), (-90, 90)))
render([(C, grey), (EL, dark), (ER, dark), (T.translate((0, 0, dz)), orange),
        (F.translate((0, 0, dz)), orange), (B.translate((0, 0, dz)), blue)],
       "drawer_open.png", 30, 55, f"Pulled out {d.TRAVEL:.0f} mm: B1 fully clear of the rack",
       ((-140, 140), (-200, 200), (-110, 110)))
render([(T, orange), (F, orange), (B, blue)], "tray_top.png", 58, 70,
       "Tray (seen from the front): B1 pocket right, spare-roll bin left, stop tabs at back",
       ((-110, 110), (-180, 10), (-60, 60)))
print("done")
