"""
Cybersigilism side-frame web: curved, tapering, thorned strokes that replace the straight brace.
Everything is a flat 2D profile extruded through the frame thickness, so it prints flat with no supports.
Coordinates are the side frame's (z depth, y height). Minimum feature width at thorn tips: 1.4 mm.
"""
import math
import cadquery as cq

TIP = 1.4          # thinnest printable tip (mm)


def bez(p, n=48):
    """cubic (4 pts) or quadratic (3 pts) Bezier, returns n points"""
    out = []
    for i in range(n):
        t = i / (n - 1)
        if len(p) == 4:
            a, b, c, d = p
            w = ((1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t ** 2, t ** 3)
            out.append(tuple(w[0] * a[k] + w[1] * b[k] + w[2] * c[k] + w[3] * d[k] for k in range(2)))
        else:
            a, b, c = p
            w = ((1 - t) ** 2, 2 * (1 - t) * t, t ** 2)
            out.append(tuple(w[0] * a[k] + w[1] * b[k] + w[2] * c[k] for k in range(2)))
    return out


def stroke_poly(pts, width_fn):
    """offset a centre line by width_fn(t) on each side; returns a closed outline"""
    n = len(pts)
    left, right = [], []
    for i, (z, y) in enumerate(pts):
        a = pts[max(i - 1, 0)]
        b = pts[min(i + 1, n - 1)]
        tz, ty = b[0] - a[0], b[1] - a[1]
        L = math.hypot(tz, ty) or 1.0
        nz, ny = -ty / L, tz / L
        w = max(width_fn(i / (n - 1)), TIP) / 2
        left.append((z + nz * w, y + ny * w))
        right.append((z - nz * w, y - ny * w))
    return left + right[::-1]


def extrude_zy(poly, x0, x1):
    pts = [(y, z) for z, y in poly]                       # YZ workplane: local (Y, Z)
    return cq.Workplane("YZ").polyline(pts).close().extrude(x1 - x0).translate((x0, 0, 0))


def blade_w(t, end=7.5, mid=4.5):
    """swells at both ends (where it joins the frame), pinches through the middle"""
    return mid + (end - mid) * abs(math.cos(math.pi * t)) ** 1.5


def thorn_w(t, base=5.0):
    return base * (1 - t) ** 1.2 + TIP * t


def point_on(pts, t):
    i = min(int(t * (len(pts) - 1)), len(pts) - 2)
    a, b = pts[i], pts[i + 1]
    L = math.hypot(b[0] - a[0], b[1] - a[1]) or 1.0
    return a, ((b[0] - a[0]) / L, (b[1] - a[1]) / L)


def sigil_web(D, H, x0, x1, corner=28.0, horns=False):
    """returns a solid: two S-blades crossing in an eye, hooked thorns, optional horns above the frame"""
    zc, yc = D / 2, H / 2
    a0, a1 = (corner - 6, corner - 6), (D - corner + 6, H - corner + 6)
    W = a1[0] - a0[0]
    blade_a = bez([a0, (a0[0] + 0.62 * W, a0[1] + 4), (a1[0] - 0.62 * W, a1[1] - 4), a1])
    blade_b = [(D - z, y) for z, y in blade_a]                        # mirror front-to-back
    shapes = [extrude_zy(stroke_poly(blade_a, blade_w), x0, x1),
              extrude_zy(stroke_poly(blade_b, blade_w), x0, x1)]

    scale = min(1.0, H / 133.35)

    def spike(p0, p1, p2, base):
        shapes.append(extrude_zy(stroke_poly(bez([p0, p1, p2], 28), lambda t: thorn_w(t, base)), x0, x1))

    # thorns: fangs off each blade that rise (or drop) away from the eye and flare out towards the posts
    L = 0.21 * H + 2
    for blade in (blade_a, blade_b):
        for t in (0.3, 0.7):
            p, _ = point_on(blade, t)
            sy = 1 if p[1] > yc else -1
            sz = 1 if p[0] > zc else -1
            spike(p, (p[0] - sz * L * 0.1, p[1] + sy * L * 0.6), (p[0] + sz * L * 0.45, p[1] + sy * L * 0.9), 4.2)

    # the eye: a pointed vesica ring round the crossing, needles out of its corners, a diamond pupil
    ew, eh = 16 * scale + 8, 7 * scale + 4
    upper = bez([(zc - ew, yc), (zc - ew * 0.35, yc + eh * 1.6), (zc + ew * 0.35, yc + eh * 1.6), (zc + ew, yc)], 40)
    lower = [(z, 2 * yc - y) for z, y in upper]
    for arc in (upper, lower):
        shapes.append(extrude_zy(stroke_poly(arc, lambda t: 2.4 + 1.4 * math.sin(math.pi * t)), x0, x1))
    room = zc - ew - 15                                          # stop short of the posts
    for sz in (-1, 1):
        tip = (zc + sz * (ew + room), yc + 2.5 * sz)
        spike((zc + sz * (ew - 2), yc), (zc + sz * (ew + room * 0.5), yc - 1.5 * sz), tip, 3.4)
    vy = (H / 2 - 12) - eh * 1.2 - 6                             # needles up and down, stopping short of the bars
    for sy in (-1, 1):
        y0 = yc + sy * eh * 1.15
        spike((zc, y0), (zc + 2.5 * sy, y0 + sy * vy * 0.5), (zc - 1.5 * sy, y0 + sy * vy), 3.0)
    d = 3.2 * scale + 2.2
    shapes.append(extrude_zy([(zc, yc - d * 1.7), (zc + d, yc), (zc, yc + d * 1.7), (zc - d, yc)], x0, x1))

    # horns: two long hooked spikes rising out of the top bar, sweeping outwards, each with a small barb
    if horns:
        for zb, s in ((D / 2 - 7, -1), (D / 2 + 7, 1)):          # tips stay clear of the top cross bars
            q = bez([(zb, H - 6), (zb + s * 1, H + 14), (zb + s * 8, H + 23), (zb + s * 17, H + 27)], 36)
            shapes.append(extrude_zy(stroke_poly(q, lambda t: 7.5 * (1 - t) ** 1.15 + TIP * t), x0, x1))
            b0 = q[14]
            spike(b0, (b0[0] - s * 4, b0[1] + 5), (b0[0] - s * 3, b0[1] + 11), 3.0)

    out = shapes[0]
    for s in shapes[1:]:
        out = out.union(s)
    return out
