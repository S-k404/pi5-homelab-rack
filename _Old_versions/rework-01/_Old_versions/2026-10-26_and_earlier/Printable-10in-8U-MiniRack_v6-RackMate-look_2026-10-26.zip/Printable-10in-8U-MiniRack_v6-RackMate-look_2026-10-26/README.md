# Printable 10-inch 8U Mini Rack — RackMate look (v6)

This is a printable box in the style of the DeskPi RackMate from Jeff Geerling's mini racks:
- solid side walls with screws at the edges
- a deep top band with a perforated top plate
- two U-handles on top, running front to back
- rubber feet

From bottom to top it holds the **Pi unit (2U)**, the **B1 face-out dock (3U)** and the **7-inch touch screen (3U)**. Every part fits a 220 mm bed.

![Front](images/rack_front.png)
![Loaded](images/rack_loaded.png)

**Size:** 260 W × 445 H (to the handle tops) × 129 D mm. The rails follow the 10-inch standard: holes 236.525 mm apart, 224 mm clear between the rails, 24 EIA holes per post at the front and rear.

**Filament:** the rack takes about **800 g of PETG (780 g in PLA)**. The solid sides account for about 185 g of that, and the deeper top for about 70 g more than before. The whole build is about **1.1 kg**: rack, B1 dock (170 g) and screen module (140 g). Buy two 1 kg spools. If you'd rather keep it light, the open-frame v5 (about 625 g) is still available.

## How it's built
- **Inner skeleton:** stacked 2U / 3U / 3U side frames with front and rear rails. Splices drop into pockets at the joints, and base bars with tabs tie the bottom together. All of these screws are countersunk, so they sit flush.
- **Side walls:** four flat 1.4 mm panels, two per side. Each screws to the front and rear posts with six M3 screws. They hide the joints and brace the frames, so the diagonal braces are gone.
- **Top box:** two halves, each with a 25 mm band and a perforated plate (84 slots). Two dovetails lock them together at the centre, so there's no extra hardware there. Each half screws to its side frames through the top splices.
- **Handles:** two U-handles (69 × 28 mm opening, 12 × 12 mm grip). Each foot takes one M5 screw into an insert in the top corner blocks.

## Strength and stability (hand calculations, in `VERIFICATION_rack.txt`)
- **Carrying the loaded rack (about 2.9 kg) by one handle:** 14 N on each foot screw, and 2 MPa in the grip.
- **5 kg on the middle of the top:** 0.7 mm sag and 3.7 MPa.
- **Tipping:** it stays put under a 5 N press on the B1 button, and a 2 N tap on the screen.
- All 30 checks pass.

## Print list
PETG or PLA, 0.2 mm layers, no supports. The STLs are already oriented.

| File (`STL_for_printing/`) | Qty | On the bed (mm) | Settings | ≈ g each (PETG) |
|---|---|---|---|---|
| `Rack_SideFrame_2U_x2.stl` | 2 | 125 × 89 × 14 | 3 walls, 20% gyroid | 42 |
| `Rack_SideFrame_3U_x4.stl` | 4 | 125 × 133 × 14 | 3 walls, 20% gyroid | 52 |
| `Rack_SidePanel_Lower_x2.stl` | 2 | 202 × 129 × 1.4, flat | solid | 46 |
| `Rack_SidePanel_Upper_x2.stl` | 2 | 202 × 129 × 1.4, flat | solid | 46 |
| `Rack_TopHalf_x2.stl` | 2 | 131 × 114 × 25, plate down | 3 walls, 15% | 69 |
| `Rack_Handle_x2.stl` | 2 | 93 × 40 × 12, on its side | 3 walls, 30% | 17 |
| `Rack_BaseBar_x2.stl` | 2 | 254 long, diagonal | 3 walls, 15% | 41 |
| `Rack_Splice_x12.stl` | 12 | 30 × 50 × 4 | 3 walls, 30% | 6 |

**Tips:**
- Print the panels outer face down on a smooth or textured plate for a clean finish.
- Silver or grey PLA/PETG gives the RackMate look.
- The gram figures are estimates; your slicer will give exact numbers.

## Hardware (rack)
| Item | Qty | Where |
|---|---|---|
| M5 heat-set inserts (6.4 mm hole) | 44 (buy 60) | 24 frame pockets + 4 top corners + 4 handle feet + 12 rail holes |
| M5 × 12 **countersunk** screws | 28 | base-bar tabs and splices (flush under the panels) |
| M5 × 12 button-head screws + washers | 16 | 4 handle feet + 12 unit ears |
| M3 heat-set inserts (Ø4 hole, 6 deep) | 24 | panel screws in the posts |
| M3 × 8 button-head screws | 24 | side panels |
| Stick-on rubber feet, 10–15 mm | 4 | under the base bars |

## Assembly
1. Melt in the inserts.
2. For each side, stack the 2U, 3U and 3U frames and screw splices across each joint, using countersunk screws.
3. Stand both sides up and screw on the base bars, again with countersunk screws.
4. Slide the two top halves together at the dovetails, set them on the frames and screw in the top splices.
5. Screw on the handles.
6. Fit the side panels: 6 M3 screws each.
7. Stick on the feet. Fit the Pi unit (bottom), the B1 dock (middle) and the screen (top).

## Check by hand
- **Pi unit width:** the Pi unit's shelf must be no wider than 224 mm.
- **Cables:** the back is open. Run the screen's HDMI and USB cables from the Pi's rear ports up the back of the rack.
- **Heat:** the sides are now closed, so air leaves through the perforated top and the open back. Keep the back clear.

The scripts in `source/` (CadQuery) regenerate every part. `verify_rack.py` re-runs the checks and `estimate_filament.py` re-runs the gram estimate.
