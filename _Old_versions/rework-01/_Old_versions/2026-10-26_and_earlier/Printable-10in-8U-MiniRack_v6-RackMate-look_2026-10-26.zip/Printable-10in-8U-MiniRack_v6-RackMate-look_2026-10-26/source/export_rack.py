import os
import cadquery as cq
import rack as r
import b1_dock as dk
import display as dp
from b1_drawer import box
import export_render as er

OUT = "out_rack"
for sub in ("STL_for_printing", "STEP_for_Onshape", "images"):
    os.makedirs(f"{OUT}/{sub}", exist_ok=True)
er.OUT = OUT


def to_bed(shape, rots):
    s = shape
    for axis, ang in rots:
        s = s.rotate((0, 0, 0), axis, ang)
    bb = s.val().BoundingBox()
    return s.translate((-bb.xmin, -bb.ymin, -bb.zmin))


prints = {
    "Rack_SideFrame_2U_x2": (r.side_frame(2), [((0, 1, 0), 90)]),
    "Rack_SideFrame_3U_x4": (r.side_frame(3), [((0, 1, 0), 90)]),
    "Rack_BaseBar_x2": (r.cross_bar(), [((0, 0, 1), 45)]),    # lying on its front face, diagonal on the bed
    "Rack_Splice_x12": (r.splice(), [((0, 1, 0), 90)]),
    "Rack_TopHalf_x2": (r.top_half(), [((1, 0, 0), 90)]),     # plate down, rims and bosses up
    "Rack_Handle_x2": (r.handle(), [((0, 1, 0), 90)]),         # lying on its side
    "Rack_SidePanel_Lower_x2": (r.side_panel(*r.panel_split()[0]), [((0, 1, 0), 90)]),   # flat
    "Rack_SidePanel_Upper_x2": (r.side_panel(*r.panel_split()[1]), [((0, 1, 0), 90)]),
}
for name, (shape, rots) in prints.items():
    p = to_bed(shape, rots)
    bb = p.val().BoundingBox()
    print(name, round(bb.xlen), round(bb.ylen), round(bb.zlen))
    cq.exporters.export(p, f"{OUT}/STL_for_printing/{name}.stl", tolerance=0.05, angularTolerance=0.1)
    cq.exporters.export(shape, f"{OUT}/STEP_for_Onshape/{name}.step")

P = r.assembly()
yc_dock = r.MODULES[0] * r.U + r.MODULES[1] * r.U / 2
dock = dk.body().translate((0, yc_dock, -dk.EAR_T))
ears = [dk.ear(s).translate((0, yc_dock, -dk.EAR_T)) for s in (1, -1)]
b1 = dk.b1_dummy().translate((0, yc_dock, -dk.EAR_T))
yc_disp = (r.MODULES[0] + r.MODULES[1]) * r.U + r.MODULES[2] * r.U / 2
disp = dp.body().translate((0, yc_disp, -dp.Z0))
dears = [dp.ear(s).translate((0, yc_disp, -dp.Z0)) for s in (1, -1)]
dclips = [c.translate((0, yc_disp, -dp.Z0)) for c in dp.clips()]
screen = dp.glass_dummy().translate((0, yc_disp, -dp.Z0))
yc_pi = r.MODULES[0] * r.U / 2
pi = box(-127, 127, yc_pi - 44.05, yc_pi + 44.05, -4, 0).union(box(-110, 110, yc_pi - 43, yc_pi + 43, 0, 117))

asm = cq.Assembly()
for n, s in P.items():
    asm.add(s, name=n, color=cq.Color("orange"))
asm.add(dock, name="b1_dock", color=cq.Color("gray")).add(b1, name="niimbot_b1", color=cq.Color("lightblue"))
asm.add(pi, name="pi_unit_envelope", color=cq.Color("gray"))
asm.add(disp, name="display_module", color=cq.Color("gray")).add(screen, name="screen_7in", color=cq.Color("black"))
asm.export(f"{OUT}/STEP_for_Onshape/Rack_5U_ASSEMBLY_with_units.step")

rack_parts = [(s, "#b9bec4") for s in P.values()]
lims = ((-165, 165), (-150, 20), (-30, 430))
er.render(rack_parts, "rack_empty.png", 30, 40, "RackMate-style 8U box: solid sides, perforated top, two handles", lims)
er.render(rack_parts + [(dock, "#55555c"), (ears[0], "#1f1f24"), (ears[1], "#1f1f24"), (b1, "#4f9fe0"), (pi, "#6b6b72"), (disp, "#55555c"), (dears[0], "#1f1f24"), (dears[1], "#1f1f24"), (screen, "#15171c")] + [(c, "#1f1f24") for c in dclips],
          "rack_loaded.png", 14, 34, "Loaded: Pi unit (2U), B1 dock (3U), 7-inch touch screen (3U)", lims)
print("done")
