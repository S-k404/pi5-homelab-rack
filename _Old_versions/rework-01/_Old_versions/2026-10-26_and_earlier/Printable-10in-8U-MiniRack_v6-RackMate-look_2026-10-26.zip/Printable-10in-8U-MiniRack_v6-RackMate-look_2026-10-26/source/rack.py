"""
Printable 10-inch 5U rack (Mini Rack 001 style: box with a vented top and a carry handle) — simple, modular, built to carry load.
Two stacked modules (2U bottom for the Pi unit, 3U top for the B1 dock) so every part fits a 220 mm bed.
Parts: side frame 2U (x2), side frame 3U (x2), cross bar (x4: front/rear, base/top), splice plate (x4).
Joints: a tab drops into a 3 mm pocket (the pocket edges stop it twisting) and one M5 screw goes
into a heat-set insert. Rails: M5 heat-set inserts at standard EIA-310 positions, front and rear.
Coordinates (mm): x across (0 = centre), y up (0 = bottom of the frames), z depth (0 = front rail face).
"""
import math
import cadquery as cq
from b1_drawer import box, cyl_z
from sigil import sigil_web

U = 44.45
D = 125.0                       # rack depth (Pi unit 121 incl. faceplate, B1 dock 95)
X_IN, X_OUT = 112.0, 126.0      # side frame: 224 mm clear opening, 252 mm over the frames
HOLE_X = 236.525 / 2            # EIA-310 10-inch hole spacing
POST = 12.0                     # post depth (z); inserts go 10 mm in
BAR = 12.0                      # top/bottom bar height
CORNER = 28.0                   # corner blocks (just big enough to wrap the joint pocket)
BRACE = 10.0                    # straight brace width (only when SIGIL = False)
SIGIL = False                   # cybersigilism web on the side frames (off: Mini Rack 001 style)
BRACE_ON = False                # the screwed-on side panels brace the frames, so no diagonal
PANEL_T, PANEL_X0, PANEL_FRONT = 1.4, X_OUT + 1.2, -4.0   # side panels sit just outside the splices
M3_INS, M3_DEPTH = 4.0, 6.0     # M3 heat-set insert hole for the panel screws
WEB_X = 118.0                   # bars and brace are 8 mm thick (x 118..126); posts are 14 mm
BOSS_D = 13.0                   # boss round each joint insert
CH_T = 2.4                      # cross bar flange thickness (L-section)
FLANGE_MID = 16.0               # flange width along the span (29.5 mm under the frames)
WEB_T = 3.0                     # cross bar web thickness
CORNER_X = 120.0                # corners: 6 mm skin (3 mm pocket floor) + a boss round the insert
INS_D, INS_DEPTH = 6.4, 10.0    # M5 heat-set insert hole
POCKET = 3.0                    # tab pocket depth in the outside face
TAB_T = 4.0
TAB_Z0, TAB_Z1 = 5.0, 35.0      # tab / pocket span along z (front; rear is mirrored)
TAB_H = 25.0                    # pocket height from the frame end
JOINT_Y = 13.0                  # joint screw height from the frame end
FIT = 0.25                      # tab clearance in the pocket
CB_H = 24.0                     # cross bar depth (flange + web)
CLR = 5.5                       # M5 clearance hole
EIA = (6.35, 22.225, 38.1)      # hole offsets inside each U


def cyl_x(x0, x1, y, z, d):
    return cq.Workplane("YZ").circle(d / 2).extrude(x1 - x0).translate((x0, y, z))


def side_frame(n):
    """right-hand side frame, n U tall. The left one is the same part turned 180 degrees."""
    H = n * U
    f = box(X_IN, X_OUT, 0, H, 0, POST)
    f = f.union(box(X_IN, X_OUT, 0, H, D - POST, D))
    f = f.union(box(WEB_X, X_OUT, 0, BAR, 0, D))
    f = f.union(box(WEB_X, X_OUT, H - BAR, H, 0, D))
    for z0, z1 in ((0, CORNER), (D - CORNER, D)):
        for y0, y1 in ((0, CORNER), (H - CORNER, H)):
            f = f.union(box(CORNER_X, X_OUT, y0, y1, z0, z1))
    # cybersigil web instead of a straight brace: two S-blades crossing in an eye (they brace both diagonals),
    # hooked thorns, and horns rising from the top of the top module
    if SIGIL:
        f = f.union(sigil_web(D, H, WEB_X, X_OUT, corner=CORNER, horns=(n == MODULES[-1])))
    elif BRACE_ON:
        p0, p1 = (CORNER - 6, CORNER - 6), (D - CORNER + 6, H - CORNER + 6)          # (z, y)
        dz, dy = p1[0] - p0[0], p1[1] - p0[1]
        L = math.hypot(dz, dy)
        oz, oy = -dy / L * BRACE / 2, dz / L * BRACE / 2
        pts = [(p0[1] + oy, p0[0] + oz), (p1[1] + oy, p1[0] + oz), (p1[1] - oy, p1[0] - oz), (p0[1] - oy, p0[0] - oz)]
        f = f.union(cq.Workplane("YZ").polyline(pts).close().extrude(X_OUT - WEB_X).translate((WEB_X, 0, 0)))
    # bosses behind each joint insert (the corner skin is only 6 mm thick)
    for zc in ((TAB_Z0 + TAB_Z1) / 2, D - (TAB_Z0 + TAB_Z1) / 2):
        for yc in (JOINT_Y, H - JOINT_Y):
            f = f.union(cyl_x(X_IN, X_OUT, yc, zc, BOSS_D))
    # rail holes: M5 inserts front and rear at every EIA position
    for k in range(n):
        for off in EIA:
            y = k * U + off
            f = f.cut(cyl_z(HOLE_X, y, -0.1, INS_DEPTH, INS_D))
            f = f.cut(cyl_z(HOLE_X, y, D - INS_DEPTH, D + 0.1, INS_D))
    # joint pockets + inserts in all four corners (outside face)
    for z0, z1 in ((TAB_Z0, TAB_Z1), (D - TAB_Z1, D - TAB_Z0)):
        zc = (z0 + z1) / 2
        for y0, y1, yc in ((-1, TAB_H, JOINT_Y), (H - TAB_H, H + 1, H - JOINT_Y)):
            f = f.cut(box(X_OUT - POCKET, X_OUT + 1, y0, y1, z0, z1))
            f = f.cut(cyl_x(X_OUT - POCKET - INS_DEPTH, X_OUT, yc, zc, INS_D))
    # M3 inserts for the side panels, in the outside face of both posts
    for y in panel_ys(n):
        for z in (POST / 2, D - POST / 2):
            f = f.cut(cyl_x(X_OUT - M3_DEPTH, X_OUT + 0.1, y, z, M3_INS))
    return f


def panel_ys(n):
    """panel screw heights in an n-U frame: first and last free spot between the rail holes, clear of the pockets"""
    H = n * U
    cand = sorted(k * U + o for k in range(n) for o in (14.3, 30.2))
    ok = [y for y in cand if TAB_H + 3 < y < H - TAB_H - 3]
    return [ok[0], ok[-1]]


def csk_x(x_face, y, z, inward=1):
    """countersink for an M5 flat head on a face at x_face (the cone goes inward, -x for inward=1)"""
    c = cq.Workplane("YZ").circle(5.2).workplane(offset=2.6).circle(2.75).loft()
    c = c.mirror("YZ") if inward == 1 else c
    return c.translate((x_face, y, z))


def cross_bar():
    """front base bar in place: an L-section (flat flange on top, the frames sit on it; one web at the front).
    It prints lying on its front face, so the flange, web and tabs all rise straight off the bed."""
    z0, z1 = TAB_Z0 + FIT, TAB_Z1 - FIT
    xt0, xt1 = X_OUT - POCKET, X_OUT - POCKET + TAB_T
    b = box(-xt1, xt1, -CH_T, 0, z0, z0 + FLANGE_MID)                  # flange: narrow along the span
    for s in (1, -1):
        a0, a1 = sorted((s * (X_IN - 8), s * xt1))
        b = b.union(box(a0, a1, -CH_T, 0, z0, z1))                     # ...full width under each frame
    b = b.union(box(-xt1, xt1, -CB_H, 0, z0, z0 + WEB_T))              # web
    for s in (1, -1):
        a0, a1 = sorted((s * xt0, s * xt1))
        b = b.union(box(a0, a1, -CH_T, TAB_H - FIT, z0, z1))           # tab, full width where it sits in the pocket
        b = b.union(box(a0, a1, -CB_H, 0, z0, z0 + 12))                # gusset down to the web
        b = b.cut(cyl_x(a0 - 1, a1 + 1, JOINT_Y, (TAB_Z0 + TAB_Z1) / 2, CLR))
        b = b.cut(csk_x(s * xt1, JOINT_Y, (TAB_Z0 + TAB_Z1) / 2, inward=1 if s > 0 else -1))   # flush under the panel
    return b


def bar_section():
    """cross bar section as rectangles (width, height, centroid depth from the top face)"""
    web_h = CB_H - CH_T
    return [(FLANGE_MID, CH_T, CH_T / 2), (WEB_T, web_h, CH_T + web_h / 2)]


def splice():
    """joins the 2U and 3U frames on the outside face; centred on the joint (y = 0)"""
    xt0, xt1 = X_OUT - POCKET, X_OUT - POCKET + TAB_T
    p = box(xt0, xt1, -(TAB_H - FIT), TAB_H - FIT, TAB_Z0 + FIT, TAB_Z1 - FIT)
    for y in (JOINT_Y, -JOINT_Y):
        p = p.cut(cyl_x(xt0 - 1, xt1 + 1, y, (TAB_Z0 + TAB_Z1) / 2, CLR))
        p = p.cut(csk_x(xt1, y, (TAB_Z0 + TAB_Z1) / 2))                    # flush under the side panel
    return p


def mirror_lr(s):
    """right side -> left side: turn 180 degrees about the vertical axis through the rack centre"""
    return s.rotate((0, 0, D / 2), (0, 1, D / 2), 180)


MODULES = (2, 3, 3)              # bottom to top: Pi unit, B1 dock, 7" display
H_TOTAL = sum(MODULES) * U       # 355.6 for 8U

# ---- top box: two perforated half-plates with a 25 mm band, locked at the seam by dovetails ----
PT = 1.8                          # top plate thickness
RIM = 25.0                        # front / rear / side band height (the RackMate's top box)
RIM_T = 2.4
RIB_Z = ()                        # no ribs needed with the deep band
SEAM = 0.2                        # half-gap at the centre seam
SEAM_W, SEAM_H = 12.0, 5.0        # strip along the seam that carries the dovetails
DOVE_Z = (35.0, D - 35.0)         # right half: tab at the first, socket at the second (the left half is the same part turned round)
HANDLE_X, HANDLE_T = 118.0, 12.0  # handles sit over the side frames
LEG_Z = (22.0, D - 22.0)          # handle legs
HANDLE_RISE = 40.0
FOOT_SCREW_Z = (34.0, D - 34.0)   # one screw per foot, into the top half's corner block
BLOCK_Z = ((12.0, 48.0), (D - 48.0, D - 12.0))
SLOT_X = [18.0 + 6.5 * i for i in range(14)]
SLOT_Z = (20.0, 36.0, 52.0, 68.0, 84.0, 100.0)


def dovetail(x_sign, zc, grow=0.0):
    """dovetail in plan (x, z): neck 8 at the seam, head 12 at 8 deep, going towards x_sign"""
    pts = [(SEAM - x_sign * 1.0, zc - 4 - grow), (SEAM + x_sign * (8 + grow), zc - 6 - grow),
           (SEAM + x_sign * (8 + grow), zc + 6 + grow), (SEAM - x_sign * 1.0, zc + 4 + grow)]
    if x_sign < 0:
        pts = [(x, z) for x, z in pts]
        pts[0] = (SEAM, pts[0][1]); pts[3] = (SEAM, pts[3][1])
    wp = cq.Workplane("XZ").polyline([(x, z) for x, z in pts]).close().extrude(-SEAM_H)
    return wp.translate((0, H_TOTAL, 0))


def top_half():
    """right-hand top half (x >= 0), in place on the frames. The left half is the same part turned round."""
    H1 = H_TOTAL
    z0, z1 = TAB_Z0 + FIT, D - TAB_Z0 - FIT
    xw = X_OUT - POCKET                                              # outer face meets the top splices
    t = box(SEAM, xw, H1, H1 + PT, z0, z1)                           # perforated plate
    t = t.union(box(SEAM, xw, H1, H1 + RIM, z0, z0 + RIM_T))         # front band
    t = t.union(box(SEAM, xw, H1, H1 + RIM, z1 - RIM_T, z1))         # rear band
    t = t.union(box(xw - RIM_T, xw, H1, H1 + RIM, z0, z1))           # side band
    t = t.union(box(SEAM, SEAM + SEAM_W, H1, H1 + SEAM_H, z0, z1))   # seam strip
    for za, zb in BLOCK_Z:                                           # corner blocks: top splice + handle foot
        t = t.union(box(xw - 10, xw, H1, H1 + RIM, za, zb))
    t = t.union(dovetail(-1, DOVE_Z[0]))                             # tab into the other half
    t = t.cut(dovetail(1, DOVE_Z[1], grow=0.2))                      # socket for the other half's tab
    slots = None
    for x in SLOT_X:
        for zc in SLOT_Z:
            sl = box(x - 1.75, x + 1.75, H1 - 1, H1 + PT + 1, zc - 6, zc + 6)
            slots = sl if slots is None else slots.union(sl)
    t = t.cut(slots)
    zc_f, zc_r = (TAB_Z0 + TAB_Z1) / 2, D - (TAB_Z0 + TAB_Z1) / 2
    for zc in (zc_f, zc_r):                                          # M5 inserts for the top splices (along x)
        t = t.cut(cyl_x(xw - INS_DEPTH, xw + 0.1, H1 + JOINT_Y, zc, INS_D))
    for fz in FOOT_SCREW_Z:                                          # M5 inserts for the handle feet (down)
        t = t.cut(cyl_y(HANDLE_X, fz, H1 + RIM - INS_DEPTH, H1 + RIM + 0.1, INS_D))
    return t


def handle():
    """right-hand U handle, front to back over the side frame, like the RackMate's"""
    y0 = H_TOTAL + RIM
    hx0, hx1 = HANDLE_X - HANDLE_T / 2, HANDLE_X + HANDLE_T / 2
    za, zb = LEG_Z[0] - 6, LEG_Z[1] + 6
    h = box(hx0, hx1, y0, y0 + HANDLE_RISE, za, zb)
    h = h.cut(box(hx0 - 1, hx1 + 1, y0 - 1, y0 + HANDLE_RISE - 12, za + 12, zb - 12))
    try:
        h = h.edges("|X").fillet(4.0)
    except Exception:
        pass
    for fz in FOOT_SCREW_Z:                                          # feet reach inwards, one screw each
        f0, f1 = (fz - 6, fz + 6)
        h = h.union(box(hx0, hx1, y0, y0 + 8, min(f0, LEG_Z[0]), max(f1, LEG_Z[0])) if fz < D / 2
                    else box(hx0, hx1, y0, y0 + 8, min(f0, LEG_Z[1]), max(f1, LEG_Z[1])))
        h = h.cut(cyl_y(HANDLE_X, fz, y0 - 0.1, y0 + 8.1, CLR))
        h = h.cut(cyl_y(HANDLE_X, fz, y0 + 4, y0 + 8.1, 9.0))
    return h


def side_panel(y0, y1):
    """right-hand side panel: a flat 1.4 mm skin over the frames, screwed to both posts"""
    p = box(PANEL_X0, PANEL_X0 + PANEL_T, y0, y1, PANEL_FRONT, D)
    for yb, n in zip(module_bottoms(), MODULES):
        for y in panel_ys(n):
            yy = yb + y
            if y0 + 5 < yy < y1 - 5:
                for z in (POST / 2, D - POST / 2):
                    p = p.cut(cyl_x(PANEL_X0 - 1, PANEL_X0 + PANEL_T + 1, yy, z, 3.4))
    return p


def module_bottoms():
    return [sum(MODULES[:i]) * U for i in range(len(MODULES))]


PANEL_Y = (-CB_H, None, None)     # filled in below once H_TOTAL is known


def panel_split():
    y_lo, y_hi = -CB_H, H_TOTAL + RIM
    mid = (y_lo + y_hi) / 2
    return (y_lo, mid), (mid, y_hi)


def band_xy(pts, width, z0, z1):
    """constant-width band along an (x, y) centre line, extruded along z"""
    n = len(pts)
    left, right = [], []
    for i, (x, y) in enumerate(pts):
        a, b = pts[max(i - 1, 0)], pts[min(i + 1, n - 1)]
        tx, ty = b[0] - a[0], b[1] - a[1]
        L = math.hypot(tx, ty) or 1.0
        nx, ny = -ty / L * width / 2, tx / L * width / 2
        left.append((x + nx, y + ny))
        right.append((x - nx, y - ny))
    return cq.Workplane("XY").polyline(left + right[::-1]).close().extrude(z1 - z0).translate((0, 0, z0))


def cyl_y(x, z, y0, y1, d):
    return cq.Workplane("XZ").circle(d / 2).extrude(-(y1 - y0)).translate((x, y0, z))


def bez3(p, n=40):
    out = []
    for i in range(n):
        t = i / (n - 1)
        w = ((1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t ** 2, t ** 3)
        out.append(tuple(sum(w[j] * p[j][k] for j in range(4)) for k in range(2)))
    return out


def band_zy(pts, width, x0, x1):
    """constant-width band along a (z, y) centre line, extruded across x"""
    n = len(pts)
    left, right = [], []
    for i, (z, y) in enumerate(pts):
        a, b = pts[max(i - 1, 0)], pts[min(i + 1, n - 1)]
        tz, ty = b[0] - a[0], b[1] - a[1]
        L = math.hypot(tz, ty) or 1.0
        nz, ny = -ty / L * width / 2, tz / L * width / 2
        left.append((y + ny, z + nz))
        right.append((y - ny, z - nz))
    return cq.Workplane("YZ").polyline(left + right[::-1]).close().extrude(x1 - x0).translate((x0, 0, 0))


def top_section(vent_frac=0.5):
    """top (both halves together) as rectangles for bending across the rack: plate (less the vents) + rims + ribs"""
    w = D - 2 * (TAB_Z0 + FIT)
    n = 2 + len(RIB_Z)
    return [(w * (1 - vent_frac), PT, PT / 2), (n * RIM_T, RIM - PT, PT + (RIM - PT) / 2)]


def assembly():
    parts = {}
    y = 0.0
    joints = []
    for i, n in enumerate(MODULES):
        r = side_frame(n).translate((0, y, 0))
        parts[f"side_m{i}_{n}U_R"] = r
        parts[f"side_m{i}_{n}U_L"] = mirror_lr(r)
        y += n * U
        joints.append(y)
    cb = cross_bar()
    rear = (0, 0, D - TAB_Z0 - TAB_Z1)                          # front span 5..35 -> rear 115..145
    parts["bar_base_front"] = cb
    parts["bar_base_rear"] = cb.translate(rear)
    th = top_half()
    parts["top_R"] = th
    parts["top_L"] = mirror_lr(th)
    hd = handle()
    parts["handle_R"] = hd
    parts["handle_L"] = mirror_lr(hd)
    for tag, (y0, y1) in zip(("lo", "hi"), panel_split()):
        pn = side_panel(y0, y1)
        parts[f"panel_{tag}_R"] = pn
        parts[f"panel_{tag}_L"] = pn.mirror("YZ")
    for k, yj in enumerate(joints):
        tag = "top" if k == len(joints) - 1 else f"joint{k}"
        sp = splice().translate((0, yj, 0))
        for nm, s in (("front", sp), ("rear", sp.translate(rear))):
            parts[f"splice_{tag}_{nm}_R"] = s
            parts[f"splice_{tag}_{nm}_L"] = mirror_lr(s)
    return parts


if __name__ == "__main__":
    for nm, s in (("side2U", side_frame(2)), ("side3U", side_frame(3)), ("bar", cross_bar()), ("splice", splice()),
                  ("top_half", top_half()), ("handle", handle()), ("panel", side_panel(*panel_split()[0]))):
        v = s.val(); bb = v.BoundingBox()
        print(nm, v.isValid(), len(s.solids().vals()), round(v.Volume()),
              [round(a, 1) for a in (bb.xmin, bb.xmax, bb.ymin, bb.ymax, bb.zmin, bb.zmax)])
