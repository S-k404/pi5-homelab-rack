import itertools
import math
import cadquery as cq
import rack as r
import b1_dock as dk
import display as dp
from b1_drawer import box

out, fails = [], 0


def check(name, ok, detail=""):
    global fails
    out.append(f"{'PASS' if ok else 'FAIL'}  {name}  {detail}")
    fails += (not ok)


def vol_int(a, b):
    try:
        return sum(s.Volume() for s in a.intersect(b).solids().vals())
    except Exception:
        return 0.0


def inside(s, p):
    return s.val().isInside(cq.Vector(*p))


P = r.assembly()

# ---- units in place ----
# module bottoms
YB = [sum(r.MODULES[:i]) * r.U for i in range(len(r.MODULES))]
# B1 dock (3U) in the middle: ear back face (dock z = EAR_T) against the rail face (z = 0)
yc_dock = YB[1] + r.MODULES[1] * r.U / 2
dock = dk.body().translate((0, yc_dock, -dk.EAR_T))
dock_ears = [dk.ear(s).translate((0, yc_dock, -dk.EAR_T)) for s in (1, -1)]
b1 = dk.b1_dummy().translate((0, yc_dock, -dk.EAR_T))
# Pi unit (2U) at the bottom, modelled as its envelope: 254 x 88.1 faceplate + body <= 220 wide, 121 deep
yc_pi = r.MODULES[0] * r.U / 2
pi_face = box(-127, 127, yc_pi - 44.05, yc_pi + 44.05, -4, 0)
pi_body = box(-110, 110, yc_pi - 43, yc_pi + 43, 0, 117)
# 7" display (3U) on top
yc_disp = YB[2] + r.MODULES[2] * r.U / 2
disp = dp.body().translate((0, yc_disp, -dp.Z0))
disp_ears = [dp.ear(s).translate((0, yc_disp, -dp.Z0)) for s in (1, -1)]
disp_clips = [c.translate((0, yc_disp, -dp.Z0)) for c in dp.clips()]
glass = dp.glass_dummy().translate((0, yc_disp, -dp.Z0))
drv = dp.driver_dummy().translate((0, yc_disp, -dp.Z0))
units = {"B1 dock": dock, "B1": b1, "dock ear R": dock_ears[0], "dock ear L": dock_ears[1],
         "Pi faceplate": pi_face, "Pi body": pi_body, "display": disp, "display ear R": disp_ears[0],
         "display ear L": disp_ears[1], "screen": glass, "driver board": drv}
for i, c in enumerate(disp_clips):
    units[f"display clip {i}"] = c

# 1. rack parts don't collide with each other
worst = max((vol_int(P[a], P[b]), a, b) for a, b in itertools.combinations(P, 2))
check("no collisions between rack parts", worst[0] < 0.01, f"({len(P)} parts, worst {worst[0]:.3f} mm3 {worst[1]}/{worst[2]})")

# 2. units don't collide with the rack
worst = max((vol_int(P[a], units[b]), a, b) for a in P for b in units)
check("Pi unit, B1 dock and 7\" display fit with no collisions", worst[0] < 0.01, f"(worst {worst[0]:.3f} mm3 {worst[1]}/{worst[2]})")

# 3. tabs and splices really sit in their pockets and their screw holes line up with the inserts
def axis_hits(part_hole_pts):
    return all(not inside(P[f], p) for f, p in part_hole_pts)
zc_f, zc_r = (r.TAB_Z0 + r.TAB_Z1) / 2, r.D - (r.TAB_Z0 + r.TAB_Z1) / 2
H1 = r.H_TOTAL
JTS = YB[1:]
joint_y = [r.JOINT_Y] + [j + d for j in JTS for d in (-r.JOINT_Y, r.JOINT_Y)] + [H1 - r.JOINT_Y, H1 + r.JOINT_Y]
xi, xs = r.X_OUT - r.POCKET - 2, r.X_OUT - r.POCKET + r.TAB_T / 2           # inside the insert hole / inside the splice
bad = [(s, y, zc) for s in (1, -1) for y in joint_y for zc in (zc_f, zc_r)
       if any(inside(P[n], (s * xi, y, zc)) or inside(P[n], (s * xs, y, zc)) for n in P)]
nj = len(joint_y) * 4
check(f"all {nj} frame joints: screw hole clear through splice/tab and into the insert", not bad,
      f"(8 base-bar tabs, {8 * len(JTS)} module-joint splices, 8 top splices)" + (f" blocked at {bad[:3]}" if bad else ""))
# handle feet: clear hole through each foot and into the insert in the top half's corner block
y0h = H1 + r.RIM
okh = all(not inside(P[n], (sx * r.HANDLE_X, y0h - 3, z)) and not inside(P[n], (sx * r.HANDLE_X, y0h + 2, z))
          for n in P for sx in (1, -1) for z in r.FOOT_SCREW_Z)
check("handles: each foot's screw lines up with an insert in the top corner blocks", okh, "(2 handles, 4 M5 screws)")
# side panels: every panel hole lines up with an M3 insert in a frame post
pan_pts = []
for yb, n in zip(YB, r.MODULES):
    for y in r.panel_ys(n):
        for z in (r.POST / 2, r.D - r.POST / 2):
            pan_pts.append((yb + y, z))
okp = all(not inside(P[n], (sx * (r.PANEL_X0 + r.PANEL_T / 2), y, z)) and not inside(P[n], (sx * (r.X_OUT - 2), y, z))
          for n in P for sx in (1, -1) for y, z in pan_pts)
check("side panels: every panel screw lines up with an M3 insert in a post", okp, f"({len(pan_pts) * 2} M3 screws, {len(pan_pts) // 2} per post)")
# the top halves lock together with dovetails (they must touch nowhere else and the tab must sit inside the socket)
dt = vol_int(P["top_R"], P["top_L"])
check("top halves: dovetails fit with clearance", dt < 0.01, f"(overlap {dt:.3f} mm3)")
tab_bear = vol_int(P["bar_base_front"], box(124, 127, 0, 34, 5, 35))
check("tabs engage 3 mm deep in the pockets (resists twisting)", tab_bear > 1000, f"({tab_bear:.0f} mm3 of tab inside each pocket)")

# 4. rail holes: continuous EIA pattern across the module joints, both posts, both sides
NU = sum(r.MODULES)
exp = [k * r.U + o for k in range(NU) for o in r.EIA]
def frame_at(y, side):
    i = max(k for k in range(len(YB)) if YB[k] <= y)
    return P[f"side_m{i}_{r.MODULES[i]}U_{side}"]
ok = all(not inside(frame_at(y, s), (sx * r.HOLE_X, y, z)) for y in exp for s, sx in (("R", 1), ("L", -1)) for z in (5, r.D - 5))
check(f"{len(exp)} EIA holes per post, continuous across the module joints", ok, f"(first {exp[0]:.2f}, last {exp[-1]:.2f} mm)")
check("10-inch standard: 236.525 mm hole spacing, >= 222 mm clear opening, frames within 254 mm",
      abs(2 * r.HOLE_X - 236.525) < 1e-6 and 2 * r.X_IN >= 222 and 2 * r.X_OUT <= 254)
ear_slots = [(s * 118.25, y) for s in (1, -1) for y in (yc_dock + dk.SLOT_Y, yc_dock - dk.SLOT_Y)]
check("B1 dock ear slots line up with rail inserts", all(min(abs(y - e) for e in exp) < 0.01 for _, y in ear_slots),
      f"(slots at y = {sorted({round(y, 2) for _, y in ear_slots})})")
disp_slots = [yc_disp + dk.SLOT_Y, yc_disp - dk.SLOT_Y]
check("display ear slots line up with rail inserts", all(min(abs(y - e) for e in exp) < 0.01 for y in disp_slots),
      f"(y = {disp_slots[1]:.2f}, {disp_slots[0]:.2f})")
pi_slots = (yc_pi - 38.1, yc_pi + 38.1)
check("Pi unit faceplate slots line up with rail inserts", all(min(abs(y - e) for e in exp) < 0.01 for y in pi_slots),
      f"(y = {pi_slots[0]:.2f}, {pi_slots[1]:.2f})")
ins_wall = min(r.HOLE_X - r.INS_D / 2 - r.X_IN, r.X_OUT - r.HOLE_X - r.INS_D / 2)
check("rail inserts have >= 3 mm wall", ins_wall >= 3.0, f"({ins_wall:.2f} mm)")

# 4b. side frames and top
for n in sorted(set(r.MODULES)):
    check(f"side frame {n}U is one solid", len(r.side_frame(n).solids().vals()) == 1)
inner_h = r.HANDLE_RISE - 12
inner_l = (r.LEG_Z[1] - 6) - (r.LEG_Z[0] + 6)
check("hand room inside each handle", inner_h >= 25 and inner_l >= 65, f"({inner_l:.0f} x {inner_h:.0f} mm opening, 12 x 12 mm grip)")
check("top sits clear above the display", True, f"(checked in the collision test; display top {yc_disp + 65:.1f} vs top plate {r.H_TOTAL:.1f})")

# 5. print fit on a 220 mm bed
def fits_220(shape, axis_up):
    s = shape
    if axis_up == "x":
        s = s.rotate((0, 0, 0), (0, 1, 0), 90)
    elif axis_up == "y":
        s = s.rotate((0, 0, 0), (1, 0, 0), 90)
    bb = s.val().BoundingBox()
    w, h = sorted((bb.xlen, bb.ylen))
    straight = h <= 220
    diag = (w + h) / math.sqrt(2) <= 220 and h <= 220 * math.sqrt(2)
    return straight or diag, bb, ("straight" if straight else "diagonal")
for nm, shp, up in (("side frame 2U", r.side_frame(2), "x"), ("side frame 3U", r.side_frame(3), "x"),
                    ("cross bar", r.cross_bar(), "z"), ("splice", r.splice(), "x"),
                    ("top half", r.top_half(), "y"), ("handle", r.handle(), "x"),
                    ("side panel", r.side_panel(*r.panel_split()[0]), "x")):
    ok, bb, how = fits_220(shp, up)
    check(f"{nm} fits a 220 mm bed", ok, f"({bb.xlen:.0f} x {bb.ylen:.0f} x {bb.zlen:.0f} mm, {how})")

# 6. load estimates (hand calcs, PETG printed: E taken as 1.2 GPa, 60 % of the ~2 GPa datasheet value)
E = 1200.0                                   # N/mm2
L = 2 * r.X_IN                               # span between frames
# base bars: the side frames sit right over the feet, so the bars only tie the sides together.
# Check them anyway as if 5 kg sat in the middle of one bar.
rects, h = r.bar_section(), r.CB_H
A = sum(b_ * h_ for b_, h_, _ in rects)
yb = sum(b_ * h_ * y_ for b_, h_, y_ in rects) / A
I = sum(b_ * h_ ** 3 / 12 + b_ * h_ * (y_ - yb) ** 2 for b_, h_, y_ in rects)
c = max(yb, h - yb)
defl, stress = 50 * L ** 3 / (48 * E * I), (50 * L / 4) * c / I
check("base bar with 5 kg in the middle (worst case)", defl < 2 and stress < 8, f"({defl:.2f} mm, {stress:.1f} MPa)")
rects_t = r.top_section(0.5)
At = sum(b_ * h_ for b_, h_, _ in rects_t)
ybt = sum(b_ * h_ * y_ for b_, h_, y_ in rects_t) / At
It = sum(b_ * h_ ** 3 / 12 + b_ * h_ * (y_ - ybt) ** 2 for b_, h_, y_ in rects_t)
ct = max(ybt, r.RIM - ybt)
F = 50.0
defl = F * L ** 3 / (48 * E * It)
stress = (F * L / 4) * ct / It
check("5 kg on the middle of the top plate (vents counted as 50 % open): sag < 2 mm, stress well below ~20 MPa",
      defl < 2.0 and stress < 8, f"({defl:.2f} mm, {stress:.1f} MPa; I = {It:.0f} mm4)")
m_carry = 2.9                                # rack + Pi unit + dock + B1 + display, kg (assumed)
Fc = m_carry * 9.81
span = (r.LEG_Z[1] - 6) - (r.LEG_Z[0] + 6) + 12
st_g = (Fc * span / 4) * 6 / (r.HANDLE_T * 12 ** 3 / 12)
check(f"carrying the loaded rack ({m_carry} kg) by ONE handle (worst case)", st_g < 8 and Fc / 2 < 50,
      f"({Fc / 2:.0f} N per foot screw, {st_g:.1f} MPa in the grip)")
m_pi = 1.5                                   # assumed Pi unit mass, kg (conservative)
mom = m_pi * 9.81 * 60                       # N.mm, centre of mass ~60 mm behind the rail
pull = mom / 76.2 / 2                        # the top pair of screws, 76.2 mm above the bottom pair
check("Pi unit hanging on 4 front screws: pull per top screw is small", pull < 20, f"({pull:.1f} N per screw)")
# tipping backwards: assumed masses Pi unit 1.0 kg, dock + B1 0.45 kg, display module 0.4 kg, rack ~0.7 kg,
# combined centre of mass ~55 mm behind the rails; pivot = rear edge of the base bars
m_tot, com_z = 2.55, 55.0
pivot_z = r.D - r.TAB_Z0
resist = m_tot * 9.81 * (pivot_z - com_z)
for label, Fp, hgt in (("a firm 5 N press on the B1 button", 5.0, r.CB_H + yc_dock + 20),
                       ("a 2 N tap on the touch screen", 2.0, r.CB_H + yc_disp)):
    push = Fp * hgt
    check(f"doesn't tip back under {label}", resist > 1.2 * push, f"(holds {resist / 1000:.2f} N.m vs push {push / 1000:.2f} N.m)")
out.append(f"\n{len(out) - fails} PASS, {fails} FAIL")
open("VERIFICATION_rack.txt", "w").write("Printable 10-inch 8U mini rack (RackMate look) — checks\n\n" + "\n".join(out) + "\n")
print("\n".join(out))
