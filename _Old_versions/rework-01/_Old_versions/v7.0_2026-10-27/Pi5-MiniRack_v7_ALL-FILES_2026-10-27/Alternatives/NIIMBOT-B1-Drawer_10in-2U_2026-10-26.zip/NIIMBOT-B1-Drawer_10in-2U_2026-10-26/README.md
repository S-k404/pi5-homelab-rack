# NIIMBOT B1 Drawer — 10-inch 2U Rack Unit

This is a pull-out drawer for the NIIMBOT B1 label printer, which measures 132 × 91 × 62 mm. It fits a 10-inch rack, and its panel and ears match the Pi 5 2U unit. The two units stacked fill a 4U DeskPi RackMate T0 exactly.

**Overall size:** 254 W × 88.1 H mm (2U). It is 178 mm deep behind the panel, or 182 mm including the fascia, which suits racks with 200 mm of depth.
**Travel:** 145 mm. Fully pulled out, the B1 clears the rack completely, so you can open its lid, change rolls or lift it out.

![Closed](images/drawer_closed.png)
![Open](images/drawer_open.png)

## How it works
- The **carcass** is a fixed sleeve with an open back. A thick front collar forms the drawer opening.
- The **tray** slides on the carcass floor and carries two compartments:
  - the B1 pocket (95 × 136 mm, which leaves 2 mm clearance all round), with finger notches for lifting the printer
  - a bin for spare label rolls or the USB cable
- The **fascia** screws to the front of the tray. It is the drawer front, and the slot in it is the pull grip. Pushing the drawer in stops when the fascia meets the collar.
- Two **stop tabs** at the back of the tray hit the collar's top lip at full travel, so the drawer can't fall out. Their tops sit 1 mm under the carcass ceiling, which keeps the extended drawer from tipping.
- The **USB-C cable** goes through notches behind the B1 pocket and in the rear wall, then out the open back. Leave about 160 mm of slack so the drawer can travel.

Seen from the front, the B1 pocket is on the right and the bin is on the left.

## Print list
PETG, 0.2 mm layers, 3 walls, 20% infill, **no supports**. All parts fit a 220 mm bed.

| File (`STL_for_printing/`) | Qty | Size (mm) | Orientation |
|---|---|---|---|
| `B1_Drawer_Carcass.stl` | 1 | 214 × 86 × 178 tall | open back down, collar on top. Needs ≥ 180 mm of Z height. |
| `B1_Drawer_Tray.stl` | 1 | 191 × 174 × 79 | floor down |
| `B1_Drawer_Fascia.stl` | 1 | 202 × 79 × 4 | front face down |
| `B1_Drawer_Ear_x2.stl` | **2** | 28 × 88 × 4 | flat. Both ears are the same part; turn one 180° for the other side. |

The STLs are already laid out in these orientations. The collar lips have 45° chamfers on the back, so the carcass prints without supports.

## Hardware
| Item | Qty | Where |
|---|---|---|
| M3 heat-set inserts (Ø4 hole, 6 deep) | 6 | 4 in the carcass collar (ear rebates), 2 in the tray front wall |
| M3 × 8 countersunk | 6 | ears to carcass (4), fascia to tray (2) |
| Rack screws | 4 | use the ones that come with the rack. The RackMate takes #10-32, which the 6.6 mm slots accept; add washers. |

## Assembly
1. Melt the six inserts in. Four go into the carcass, in the rebated strips either side of the opening; two go into the tray's front wall.
2. Screw an ear onto each side of the carcass front.
3. **Slide the tray in from the open back**, front wall first, until the stop tabs reach the collar. (The tabs can't pass the collar, which is what makes them a stop.)
4. Screw the fascia onto the tray front through the opening.
5. Push the drawer closed. Set the B1 in the pocket and route its USB-C cable out the back.
6. Rack it below the Pi unit.

To remove the tray later, take off the fascia (2 screws), unrack the unit and slide the tray out the back.

## Check by hand
- **B1 port and label exit sides:** the pocket is open-topped, and the cable notch sits at the back of the pocket. If your B1's USB-C port is on a side, the finger notches will pass the cable instead.
- **Drawer feel:** PETG slides on PETG, but the carcass floor is printed vertically, so it has layer lines. A light sand or a little dry PTFE spray makes it smoother.
- **Droop at full extension:** expect a few millimetres at the fascia with the B1 in the tray. If the rack has a free U below, a 0.5U shelf under the carcass stiffens it.

Full measured check: `VERIFICATION.txt` (23 pass, 0 fail). The source scripts in `source/` generate every file.
