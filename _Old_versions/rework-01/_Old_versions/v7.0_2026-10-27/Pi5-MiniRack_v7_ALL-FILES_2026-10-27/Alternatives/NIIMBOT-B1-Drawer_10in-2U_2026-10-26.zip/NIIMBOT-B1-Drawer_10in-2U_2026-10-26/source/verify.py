import itertools
import cadquery as cq
import b1_drawer as d

out = []
fails = 0


def check(name, ok, detail=""):
    global fails
    out.append(f"{'PASS' if ok else 'FAIL'}  {name}  {detail}")
    if not ok:
        fails += 1


def vol_int(a, b):
    try:
        r = a.intersect(b)
        return sum(s.Volume() for s in r.solids().vals())
    except Exception:
        return 0.0


C = d.carcass(); T = d.tray(); F = d.fascia(); EL = d.ear(-1); ER = d.ear(1); B = d.b1_dummy()


def moving(dz):
    return [p.translate((0, 0, dz)) for p in (T, F, B)]


fixed = {"carcass": C, "ear L": EL, "ear R": ER}

# 1/2 closed and open: no collisions
for label, dz in (("closed", 0.0), ("fully open", -d.TRAVEL + 0.2)):
    mv = dict(zip(("tray", "fascia", "B1"), moving(dz)))
    allp = {**fixed, **mv}
    worst = max((vol_int(allp[a], allp[b]), a, b) for a, b in itertools.combinations(allp, 2)
                if not {a, b} <= {"tray", "fascia", "B1"})
    check(f"no collisions, drawer {label}", worst[0] < 0.01, f"(max overlap {worst[0]:.3f} mm3, {worst[1]}/{worst[2]})")

# 3 stop actually stops
over = vol_int(T.translate((0, 0, -d.TRAVEL - 1.5)), C)
check("travel stop engages (tabs hit collar lip past full travel)", over > 1, f"(overlap at +1.5 mm: {over:.1f} mm3)")

# 4 insertion from the back: sweep the bare tray from behind to fully open
clash = []
for z in range(int(d.CAR_D) + 10, int(-d.TRAVEL), -5):
    v = vol_int(T.translate((0, 0, z)), C)
    if v > 0.01:
        clash.append((z, round(v, 2)))
check("tray slides in from the open back to full travel", not clash, str(clash[:3]))

# 5 printer fully out of the rack when open
b_open_zmax = B.val().BoundingBox().zmax - d.TRAVEL
check("B1 fully in front of the rack when open", b_open_zmax < 0, f"(rear of B1 at z = {b_open_zmax:.1f} mm)")
b_top = B.val().BoundingBox().ymax
check("B1 passes under the collar lip", b_top < d.OPEN_TOP - 3, f"(B1 top {b_top:.1f}, lip {d.OPEN_TOP})")

# 6 pocket clearance
check("B1 pocket clearance", d.POCKET_W - d.B1[0] >= 3 and d.POCKET_L - d.B1[2] >= 3,
      f"({d.POCKET_W - d.B1[0]:.1f} mm wide, {d.POCKET_L - d.B1[2]:.1f} mm long)")

# 7 chamfer geometry probes
def inside(shape, p):
    return shape.val().isInside(cq.Vector(*p))
check("collar lip chamfer present (top)", inside(C, (0, 39, d.COLLAR_D + 3.5)) and not inside(C, (0, 39, d.COLLAR_D + 4.5)))
check("collar lip chamfer present (sides)", inside(C, (100, 0, 22)) and not inside(C, (100, 0, 30))
      and inside(C, (-100, 0, 22)) and not inside(C, (-100, 0, 30)))

# 8 rack standard
eb = [e.val().BoundingBox() for e in (EL, ER)]
check("panel width 254 mm", abs((eb[1].xmax - eb[0].xmin) - 254) < 0.01, f"({eb[1].xmax - eb[0].xmin:.2f})")
check("panel height 88.1 mm (2U)", abs(eb[0].ymax - eb[0].ymin - 88.1) < 0.01)
check("rack slots 236.5 mm apart", inside(EL, (-118.25, 38.1, 2)) is False and inside(ER, (118.25, -38.1, 2)) is False
      and inside(ER, (118.25, 0, 2)))
cb = C.val().BoundingBox()
check("body fits between 10-inch rails (<= 222 mm)", cb.xmax - cb.xmin <= 218, f"({cb.xmax - cb.xmin:.0f} mm)")
check("body stays inside 2U height", cb.ymax - cb.ymin <= 88.1, f"({cb.ymax - cb.ymin:.0f} mm)")
depth = cb.zmax + d.FASCIA_T
check("depth fits RackMate T0/T1 (200 mm)", cb.zmax <= 195, f"({cb.zmax:.0f} behind panel, {depth:.0f} incl. fascia)")
check("fascia stays inside 2U panel outline",
      F.val().BoundingBox().ymax <= 44.05 and F.val().BoundingBox().ymin >= -44.05)

# 9 insert wall margins
m_ear = min(d.EAR_SCREW_X - d.INSERT_D / 2 - d.OPEN_HALF_W, d.CAR_W / 2 - d.EAR_SCREW_X - d.INSERT_D / 2)
check("ear inserts have >= 1.5 mm wall", m_ear >= 1.5, f"({m_ear:.1f} mm)")
check("fascia inserts sit in solid front wall", d.FRONT_WALL_T >= d.INSERT_DEPTH + 1.5)

# 10 bed fit (220 mm bed)
for name, p, orient in (("carcass", C, "back face down"), ("tray", T, "floor down"),
                        ("fascia", F, "front face down"), ("ear", EL, "flat")):
    bb = p.val().BoundingBox()
    dims = sorted([bb.xlen, bb.ylen, bb.zlen])
    check(f"{name} fits 220 mm bed ({orient})", dims[1] <= 220 and dims[2] <= 220, f"({bb.xlen:.0f} x {bb.ylen:.0f} x {bb.zlen:.0f})")

# 11 anti-tip when open: gap between tab top and ceiling
check("anti-tip: tab top 1 mm under ceiling", 0.5 <= d.CEIL - d.TAB_TOP <= 1.5, f"({d.CEIL - d.TAB_TOP:.1f} mm)")

out.append(f"\n{len(out) - fails} PASS, {fails} FAIL   (travel {d.TRAVEL:.0f} mm)")
open("VERIFICATION.txt", "w").write("NIIMBOT B1 drawer — 10-inch 2U — geometric checks\n\n" + "\n".join(out) + "\n")
print("\n".join(out))
